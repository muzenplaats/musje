FONTLOG for the LV GoldenAge font
=================================

This file provides detailed information on the LV GoldenAge font software. This information
should be distributed along with the LV GoldenAge fonts and any derivative works.

Basic font information
----------------------

LV GoldenAge is a typeface designed and copyrighted by Donald Rice for the Finale notation
program. Recently, Don made it freely available to the public. This variant was remapped for
use with LilyPond 2.18.2 by Abraham Lee and given the name "LV GoldenAge", both to distinguish
it from the original font and to provide a reminder of where it came from. This font software
is not designed for use in a word-processing application, although all the glyphs may be
accessed at their respective Unicode points.

More information about LilyPond can be found at:

http://www.lilypond.org/

Changelog
---------

16 February 2015 (Abraham Lee) LV GoldenAge version 1.0
- Initial design to be compatible with LilyPond 2.18.2.
