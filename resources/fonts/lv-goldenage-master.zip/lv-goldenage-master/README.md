LV GoldenAge Font Family
========================

To make the most of these fonts, there are two text fonts that should be 
installed in the normal font installation location (which is different for 
each OS):

- **GoldenAge Text**: A hand-written font designed to represent the clear type
  of traditional music copyists. This is the default text font in the 
  ``lv-goldenage.ily`` stylesheet.
- **GoldenAge Title**: Similar to the above, but more suited for titling.

Any questions relating to font installation and usage can be sent to
[Abraham Lee](mailto:tisimst.lilypond@gmail.com).

These two fonts were created and copyrighted (c) 1996 by Donald Rice.
