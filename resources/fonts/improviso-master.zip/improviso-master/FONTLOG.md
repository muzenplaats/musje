FONTLOG for the Improviso font
==============================

This file provides detailed information on the Improviso Font Software. This information should
be distributed along with the Improviso fonts and any derivative works.


Basic font information
----------------------

Improviso is a typeface designed by Abraham Lee to resemble the style of traditional hand
copyists. This font software is not designed for use in a word-processing application, although
all the glyphs may be accessed at their respective Unicode points. It was originally designed
for use with GNU LilyPond, the automatic music engraver.

More information about LilyPond can be found at:

http://www.lilypond.org/

Changelog
---------

10 September 2014 (Abraham Lee) Improviso version 1.0
- Initial design to be compatible with LilyPond 2.18.2.

25 October 2014 (Abraham Lee) Improviso version 1.0
- Added WOFF font file support and added piano brace font in OTF, SVG and WOFF formats

20 January 2015 (Abraham Lee) Improviso version 1.0
- Fixed open contour artifacts in some glyphs

23 January 2015 (Abraham Lee) Improviso version 1.0
- Fixed mis-shifted contour in clefs.C_change glyph
