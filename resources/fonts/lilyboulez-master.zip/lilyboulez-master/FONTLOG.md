FONTLOG for the LilyBoulez font
================================

This file provides detailed information on the LilyBoulez font software. This information
should be distributed along with the LilyBoulez fonts and any derivative works.

Basic font information
----------------------

LilyBoulez is a typeface designed by Eric Grunin, remapped for use with LilyPond 2.18.2 by
Abraham Lee. This font software is not designed for use in a word-processing application,
although all the glyphs may be accessed at their respective Unicode points.

More information about LilyPond can be found at:

http://www.lilypond.org/

Changelog
---------

8 February 2015 (Abraham Lee) LilyBoulez version 1.0
- Initial design to be compatible with LilyPond 2.18.2.
