FONTLOG for the Gutenberg1939 font
==================================

This file provides detailed information on the Gutenberg1939 Font Software. This information
should be distributed along with the Gutenberg1939 fonts and any derivative works.


Basic font information
----------------------

Gutenberg1939 is a typeface designed by Abraham Lee to mimic an old-fashioned metal-type style
of music publishing. The glyph set comes from a facsimile found from "Buchgwerbliches
Hilfsbuch" by Otto Sauberlich. This font software is not designed for use in a word-processing
application, although all the glyphs may be accessed at their respective Unicode points. It was
originally designed for use with LilyPond, the automatic music engraver.

More information about LilyPond can be found at:

http://www.lilypond.org/

Changelog
---------

30 July 2014 (Abraham Lee) Gutenberg1939 version 1.0
- Initial design to be compatible with LilyPond 2.18.2.

26 October 2014 (Abraham Lee) Gutenberg1939 version 1.0
- Added WOFF font file support and added piano brace font in OTF, SVG, and WOFF formats
