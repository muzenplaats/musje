# MIDI.js
Modified from https://github.com/mudcube/MIDI.js/ for ES6 package.
