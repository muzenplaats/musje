
export default class SclPitch {
  constructor(sclPitch) {
    this.name = 'scl-pitch'
    this.sclName = sclPitch.sclName
    this.sclStep = sclPitch.sclStep
  }

  toString() {}
  toJSON() {}
}
