import fs from 'fs'
import SclFile from './SclFile'

export const makeSclDatabaseInAFile(folderName) {
  let db = ''

  return db
}
