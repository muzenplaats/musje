// import './test/testXml'
// import './test/testMxl'
// import helloworld from '../dist/scores/musicXml/helloworld.musicxml'
// import reve from '../dist/scores/musicXml/reve.musicxml'
// import Score from './model/Score'

// const reveScore = Score.fromMxl(reve)
// console.log(reveScore)
// console.log('' + reveScore)
// console.log(reveScore.toMxl())

// import appElement from './appElement_old'

// import appElement from './tools/toolsElement'

import appElement from './appElement'
// import appElement from './fromMxlElement'

document.body.appendChild(appElement())
